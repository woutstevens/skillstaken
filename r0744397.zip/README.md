# 1ITF vervolg skillstaken 
Dit is de uitwerking van **skillstaak 2** en **Skillstaak 3** door Wout Stevens uit 1ITF H van de Thomas More Hogeschool (campus Geel).

<p align="center">
    <img src="https://www.thomasmore.be/themes/wundertheme/logo.svg" alt="Thomas More Kempen" width="300" />
</p>

